
AutoDrive Car Mart - IA#2 Project
Folder: 1234567_IA2_S1AY26

Files:
- Codes/: HTML pages (index.html, products.html, login.html, register.html, cart.html, checkout.html, about.html)
- Assets/: logo, palette, wireframes, placeholder car images
- style.css : global stylesheet
- script.js : JavaScript with product list and cart functionality
- storyboard.docx : Storyboard document (or storyboard.txt if docx creation failed)

Reference file provided by user (assignment brief): /mnt/data/New IA2 Doc.docx

How to run:
- Unzip the folder.
- Open Codes/index.html in a browser (ensure style.css and script.js are referenced relatively as provided).

Hosted link:
- To host, upload zipped folder to GitHub and deploy via Netlify (drag-and-drop the folder or connect repo).

